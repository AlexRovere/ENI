package parent;

public abstract class Parent {
	  public Parent() {
		super();
	}

	public void respirer () {
	    System.out.println("le parent respire");
	  }

	  public void manger () {
	   System.out.println("le parent mange");
	  }
	}