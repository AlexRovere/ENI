package parent;

public class Enfant extends Parent {

	public Enfant() {
		super();
	}

	public void respirer() {
		System.out.println("l'enfant respire");
	}

	public void jouer() {
		System.out.println("l'enfant joue");
	}
}