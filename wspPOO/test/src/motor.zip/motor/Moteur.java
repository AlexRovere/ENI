package motor;

public class Moteur {

	public Moteur() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	public void consommer(float deltaVitesse) {
		
	}

}
