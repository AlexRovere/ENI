package test;

public abstract class Animal {
	
	
	public void manger() {	
		System.out.println("l'animal mange");
	}
	
	public void courrir() {
		System.out.println("l'animal court");

	}
	
}
