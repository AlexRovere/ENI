package test;


public abstract class Main {
	public static void main(String[] args) {
		
		
		Chien chien = new Chien();
		chien.manger(); // fonction de chien
		chien.courrir(); // fonction d'animal
		chien.sauter(); // fonction de chien
		
//		Animal chien = new Chien();
//		chien.manger(); // fonction de chien
//		chien.courrir(); // fonction d'animal
//		chien.sauter(); // fonction de chien IMPOSSIBLE n'existe pas dans animal

	}
}
