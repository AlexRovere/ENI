package com.example.ludotheque;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LudothequeApplication {

    public static void main(String[] args) {
        SpringApplication.run(LudothequeApplication.class, args);
    }

}
