package com.example.ludotheque.dal;

import com.example.ludotheque.bo.Client;

import java.util.List;
import java.util.Optional;

public interface IClientRepository extends ICrudRepository<Client> {

}
