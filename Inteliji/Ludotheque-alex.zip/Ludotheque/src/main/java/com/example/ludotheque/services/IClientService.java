package com.example.ludotheque.services;

import com.example.ludotheque.bo.Client;

import java.util.List;
import java.util.Optional;

public interface IClientService extends ICrudService <Client>{

}
