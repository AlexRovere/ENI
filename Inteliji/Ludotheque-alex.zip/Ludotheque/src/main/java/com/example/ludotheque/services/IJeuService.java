package com.example.ludotheque.services;

import com.example.ludotheque.bo.Jeu;

public interface IJeuService  extends ICrudService<Jeu>{
}
