package com.example.ludotheque.bo;

public enum GenreJeu {
	action,
	rpg,
	aventure,
	coop,
	plateforme,
	fps,
	str
}
