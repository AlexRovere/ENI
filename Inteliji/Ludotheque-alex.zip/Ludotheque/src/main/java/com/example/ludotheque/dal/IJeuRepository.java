package com.example.ludotheque.dal;

import com.example.ludotheque.bo.Client;
import com.example.ludotheque.bo.Jeu;

public interface IJeuRepository extends ICrudRepository<Jeu> {

}
