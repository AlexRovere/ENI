package animal;

class Chat extends Animal {

	@Override
	public void manger() {
    	System.out.println("le chat mange");
    }
	
	public void sauter() {
    	System.out.println("le chat saute");

	}
   
}