package animal;

public class Animal {
	
	
	public void manger() {	
		System.out.println("l'animal mange");
	}
	
	public void courrir() {
		System.out.println("l'animal court");

	}
	
	void dormir () {
		System.out.println("l'animal dort");
	}

}
